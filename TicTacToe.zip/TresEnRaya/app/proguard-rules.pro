# Reglas ProGuard/R8 específicas del proyecto.
# Por defecto no se necesita nada especial para Compose + Kotlin puro.
