package com.tresenraya.game.model

/**
 * Estado completo e inmutable de una partida.
 * El ViewModel expone este estado a través de un StateFlow y la UI
 * simplemente lo renderiza (patrón unidireccional de datos).
 */
data class GameState(
    val board: List<Player> = List(9) { Player.NONE },
    val currentPlayer: Player = Player.X,
    val winner: Player = Player.NONE,
    val winningLine: List<Int>? = null,
    val isDraw: Boolean = false,
    val isGameOver: Boolean = false,
    val gameMode: GameMode = GameMode.PLAYER_VS_PLAYER,
    val scoreX: Int = 0,
    val scoreO: Int = 0,
    val draws: Int = 0,
    val isBotThinking: Boolean = false
)
