package com.tresenraya.game.model

/**
 * Todas las combinaciones ganadoras posibles en un tablero de 3x3,
 * expresadas como índices de la lista plana (0..8):
 *
 *  0 | 1 | 2
 *  --+---+--
 *  3 | 4 | 5
 *  --+---+--
 *  6 | 7 | 8
 */
object WinLines {
    val ALL: List<List<Int>> = listOf(
        // Filas
        listOf(0, 1, 2),
        listOf(3, 4, 5),
        listOf(6, 7, 8),
        // Columnas
        listOf(0, 3, 6),
        listOf(1, 4, 7),
        listOf(2, 5, 8),
        // Diagonales
        listOf(0, 4, 8),
        listOf(2, 4, 6)
    )
}
