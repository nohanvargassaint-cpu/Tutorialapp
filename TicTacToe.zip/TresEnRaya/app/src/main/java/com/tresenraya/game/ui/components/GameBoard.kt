package com.tresenraya.game.ui.components

import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.tresenraya.game.model.Player
import com.tresenraya.game.ui.theme.ColorO
import com.tresenraya.game.ui.theme.ColorX
import com.tresenraya.game.ui.theme.WinHighlight
import com.tresenraya.game.ui.theme.boardLineColor

/**
 * Tablero de 3x3. Recibe el estado plano del tablero (lista de 9 [Player])
 * y delega el clic de cada casilla hacia arriba mediante [onCellClick].
 *
 * [winningLine] contiene los 3 índices a resaltar cuando hay un ganador,
 * o null si no lo hay todavía.
 */
@Composable
fun GameBoard(
    board: List<Player>,
    winningLine: List<Int>?,
    enabled: Boolean,
    onCellClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val lineColor = boardLineColor()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(10.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            for (row in 0 until 3) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    for (col in 0 until 3) {
                        val index = row * 3 + col
                        GameCell(
                            player = board[index],
                            isWinningCell = winningLine?.contains(index) == true,
                            enabled = enabled && board[index] == Player.NONE,
                            lineColor = lineColor,
                            onClick = { onCellClick(index) },
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Una casilla individual del tablero. Anima la aparición de la ficha con
 * un "pop" de escala y resalta con un color distinto si forma parte de
 * la línea ganadora.
 */
@Composable
private fun GameCell(
    player: Player,
    isWinningCell: Boolean,
    enabled: Boolean,
    lineColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when {
        isWinningCell -> WinHighlight.copy(alpha = 0.18f)
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    }

    val borderColor = if (isWinningCell) WinHighlight else lineColor

    // Animación de "pop" al aparecer la ficha
    val scale by animateFloatAsState(
        targetValue = if (player != Player.NONE) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "cellScale"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(width = 1.5.dp, color = borderColor, shape = RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        when (player) {
            Player.X -> Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "X",
                tint = if (isWinningCell) WinHighlight else ColorX,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(14.dp)
                    .scale(scale)
            )
            Player.O -> Icon(
                imageVector = Icons.Filled.Circle,
                contentDescription = "O",
                tint = if (isWinningCell) WinHighlight else ColorO,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
                    .scale(scale)
            )
            Player.NONE -> Unit
        }
    }
}
