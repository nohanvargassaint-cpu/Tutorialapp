package com.tresenraya.game.model

/**
 * Modo de juego seleccionado por el usuario.
 */
enum class GameMode {
    PLAYER_VS_PLAYER,
    PLAYER_VS_BOT
}
