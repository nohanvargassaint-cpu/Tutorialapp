package com.tresenraya.game.model

/**
 * Representa el contenido de una casilla del tablero.
 */
enum class Player {
    X,
    O,
    NONE;

    fun opponent(): Player = when (this) {
        X -> O
        O -> X
        NONE -> NONE
    }
}
