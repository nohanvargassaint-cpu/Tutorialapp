package com.tresenraya.game.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta - Modo claro
val PrimaryLight = Color(0xFF3F51F3)
val OnPrimaryLight = Color(0xFFFFFFFF)
val SecondaryLight = Color(0xFFF35B3F)
val BackgroundLight = Color(0xFFF7F7FB)
val SurfaceLight = Color(0xFFFFFFFF)
val BoardLineLight = Color(0xFFDADCE6)

// Paleta - Modo oscuro
val PrimaryDark = Color(0xFF8C96FF)
val OnPrimaryDark = Color(0xFF16193A)
val SecondaryDark = Color(0xFFFF8A70)
val BackgroundDark = Color(0xFF111323)
val SurfaceDark = Color(0xFF1B1E36)
val BoardLineDark = Color(0xFF33365A)

// Colores fijos para las fichas (misma intención en ambos temas)
val ColorX = Color(0xFF3F51F3) // Azul-violeta
val ColorO = Color(0xFFF35B3F) // Naranja coral
val WinHighlight = Color(0xFF35C97C) // Verde para la línea ganadora
