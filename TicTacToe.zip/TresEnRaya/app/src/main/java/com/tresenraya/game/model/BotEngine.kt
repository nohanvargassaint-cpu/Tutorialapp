package com.tresenraya.game.model

/**
 * IA sencilla/media para el modo Jugador vs Bot.
 *
 * Estrategia (en orden de prioridad):
 *   1. Si el bot puede ganar en este turno, gana.
 *   2. Si el rival puede ganar en su próximo turno, lo bloquea.
 *   3. Si el centro está libre, lo toma (mejor casilla estratégicamente).
 *   4. Si hay una esquina libre, la toma.
 *   5. En su defecto, toma cualquier casilla libre.
 *
 * Esto da una dificultad "media": el bot no es imbatible (no implementa
 * minimax completo) pero juega de forma razonablemente inteligente y
 * nunca regala partidas de forma obvia.
 */
object BotEngine {

    private const val CENTER = 4
    private val CORNERS = listOf(0, 2, 6, 8)

    fun findBestMove(board: List<Player>, botPlayer: Player): Int {
        val human = botPlayer.opponent()

        // 1. Buscar jugada ganadora para el bot
        findWinningMove(board, botPlayer)?.let { return it }

        // 2. Bloquear jugada ganadora del humano
        findWinningMove(board, human)?.let { return it }

        // 3. Tomar el centro
        if (board[CENTER] == Player.NONE) return CENTER

        // 4. Tomar una esquina libre
        val freeCorner = CORNERS.filter { board[it] == Player.NONE }
        if (freeCorner.isNotEmpty()) return freeCorner.random()

        // 5. Cualquier casilla libre
        val freeAny = board.indices.filter { board[it] == Player.NONE }
        return freeAny.random()
    }

    /**
     * Devuelve el índice donde [player] podría completar una línea ganadora
     * jugando una sola ficha, o null si no existe tal jugada.
     */
    private fun findWinningMove(board: List<Player>, player: Player): Int? {
        for (line in WinLines.ALL) {
            val values = line.map { board[it] }
            val playerCount = values.count { it == player }
            val emptyCount = values.count { it == Player.NONE }
            if (playerCount == 2 && emptyCount == 1) {
                return line.first { board[it] == Player.NONE }
            }
        }
        return null
    }
}
