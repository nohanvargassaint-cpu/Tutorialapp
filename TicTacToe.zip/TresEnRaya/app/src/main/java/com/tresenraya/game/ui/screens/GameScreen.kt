package com.tresenraya.game.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tresenraya.game.model.GameMode
import com.tresenraya.game.model.Player
import com.tresenraya.game.ui.components.GameBoard
import com.tresenraya.game.ui.components.ModeSelector
import com.tresenraya.game.ui.components.ScoreBoard
import com.tresenraya.game.viewmodel.GameViewModel

/**
 * Pantalla única de la app. Observa el [GameViewModel] y arma la jerarquía
 * visual completa: título, selector de modo, marcador, tablero y acciones.
 */
@Composable
fun GameScreen(viewModel: GameViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()

    Scaffold { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(paddingValues)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Tres en Raya",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(16.dp))

            ModeSelector(
                selectedMode = state.gameMode,
                onModeSelected = { viewModel.setGameMode(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            ScoreBoard(
                scoreX = state.scoreX,
                scoreO = state.scoreO,
                draws = state.draws
            )

            Spacer(modifier = Modifier.height(24.dp))

            StatusBanner(
                currentPlayer = state.currentPlayer,
                winner = state.winner,
                isDraw = state.isDraw,
                isBotThinking = state.isBotThinking,
                gameMode = state.gameMode
            )

            Spacer(modifier = Modifier.height(16.dp))

            GameBoard(
                board = state.board,
                winningLine = state.winningLine,
                enabled = !state.isGameOver && !state.isBotThinking,
                onCellClick = { viewModel.onCellClicked(it) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.resetRound() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reiniciar ronda")
                }

                Button(
                    onClick = { viewModel.resetFullScore() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Icon(Icons.Filled.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reiniciar marcador")
                }
            }
        }
    }
}

/**
 * Banner de estado: indica de quién es el turno, si el bot está pensando,
 * o quién ganó / si hubo empate.
 */
@Composable
private fun StatusBanner(
    currentPlayer: Player,
    winner: Player,
    isDraw: Boolean,
    isBotThinking: Boolean,
    gameMode: GameMode
) {
    val message = when {
        winner == Player.X -> "¡Ganó el Jugador X! 🎉"
        winner == Player.O && gameMode == GameMode.PLAYER_VS_BOT -> "Ganó el Bot 🤖"
        winner == Player.O -> "¡Ganó el Jugador O! 🎉"
        isDraw -> "Empate 🤝"
        isBotThinking -> "El bot está pensando..."
        currentPlayer == Player.X -> "Turno de: Jugador X"
        gameMode == GameMode.PLAYER_VS_BOT -> "Turno de: Bot"
        else -> "Turno de: Jugador O"
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = message,
            style = MaterialTheme.typography.titleMedium
        )
        AnimatedVisibility(visible = isBotThinking) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Spacer(modifier = Modifier.width(8.dp))
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp
                )
            }
        }
    }
}
