package com.tresenraya.game.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tresenraya.game.model.BotEngine
import com.tresenraya.game.model.GameMode
import com.tresenraya.game.model.GameState
import com.tresenraya.game.model.Player
import com.tresenraya.game.model.WinLines
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel único de la pantalla de juego. Aplica el patrón MVVM:
 * mantiene el [GameState] como fuente de verdad y expone funciones
 * públicas para que la UI (Composables) dispare eventos.
 *
 * El bot juega en una corrutina lanzada en [viewModelScope], con un
 * pequeño delay para simular "pensar" y no sentirse instantáneo/robótico.
 */
class GameViewModel : ViewModel() {

    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    /** El bot siempre juega con 'O'; el humano con 'X'. */
    private val botPlayer = Player.O

    fun onCellClicked(index: Int) {
        val current = _state.value

        if (!isMoveValid(current, index)) return

        applyMove(index, current.currentPlayer)

        // Si estamos en modo Bot y le toca a la máquina, dispara su jugada
        val afterMoveState = _state.value
        if (current.gameMode == GameMode.PLAYER_VS_BOT &&
            !afterMoveState.isGameOver &&
            afterMoveState.currentPlayer == botPlayer
        ) {
            triggerBotMove()
        }
    }

    fun setGameMode(mode: GameMode) {
        _state.update { it.copy(gameMode = mode) }
        resetRound()
    }

    /** Reinicia solo el tablero, conservando el marcador acumulado. */
    fun resetRound() {
        _state.update {
            it.copy(
                board = List(9) { Player.NONE },
                currentPlayer = Player.X,
                winner = Player.NONE,
                winningLine = null,
                isDraw = false,
                isGameOver = false,
                isBotThinking = false
            )
        }
    }

    /** Reinicia tablero y marcador por completo. */
    fun resetFullScore() {
        _state.update {
            it.copy(
                board = List(9) { Player.NONE },
                currentPlayer = Player.X,
                winner = Player.NONE,
                winningLine = null,
                isDraw = false,
                isGameOver = false,
                isBotThinking = false,
                scoreX = 0,
                scoreO = 0,
                draws = 0
            )
        }
    }

    // ---------------------------------------------------------------
    // Lógica interna
    // ---------------------------------------------------------------

    private fun isMoveValid(state: GameState, index: Int): Boolean {
        if (state.isGameOver) return false
        if (state.isBotThinking) return false
        if (index !in state.board.indices) return false
        if (state.board[index] != Player.NONE) return false
        return true
    }

    private fun applyMove(index: Int, player: Player) {
        val newBoard = _state.value.board.toMutableList()
        newBoard[index] = player

        val winningLine = findWinningLine(newBoard, player)
        val isDraw = winningLine == null && newBoard.none { it == Player.NONE }

        _state.update {
            it.copy(
                board = newBoard,
                winner = if (winningLine != null) player else Player.NONE,
                winningLine = winningLine,
                isDraw = isDraw,
                isGameOver = winningLine != null || isDraw,
                currentPlayer = player.opponent()
            )
        }

        if (winningLine != null) {
            addScore(player)
        } else if (isDraw) {
            _state.update { it.copy(draws = it.draws + 1) }
        }
    }

    private fun addScore(winner: Player) {
        _state.update {
            when (winner) {
                Player.X -> it.copy(scoreX = it.scoreX + 1)
                Player.O -> it.copy(scoreO = it.scoreO + 1)
                Player.NONE -> it
            }
        }
    }

    private fun triggerBotMove() {
        _state.update { it.copy(isBotThinking = true) }
        viewModelScope.launch {
            // Pequeño retraso para que la jugada del bot se sienta natural
            delay(600)

            val current = _state.value
            // Verificación de seguridad por si el usuario reinició mientras "pensaba"
            if (current.isGameOver || current.currentPlayer != botPlayer) {
                _state.update { it.copy(isBotThinking = false) }
                return@launch
            }

            val move = BotEngine.findBestMove(current.board, botPlayer)
            _state.update { it.copy(isBotThinking = false) }
            applyMove(move, botPlayer)
        }
    }

    private fun findWinningLine(board: List<Player>, player: Player): List<Int>? {
        return WinLines.ALL.firstOrNull { line ->
            line.all { board[it] == player }
        }
    }
}
