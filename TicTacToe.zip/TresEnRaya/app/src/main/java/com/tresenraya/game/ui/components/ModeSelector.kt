package com.tresenraya.game.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.tresenraya.game.model.GameMode

/**
 * Selector segmentado para alternar entre modo 2 Jugadores y modo vs Bot.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModeSelector(
    selectedMode: GameMode,
    onModeSelected: (GameMode) -> Unit,
    modifier: Modifier = Modifier
) {
    SingleChoiceSegmentedButtonRow(modifier = modifier.fillMaxWidth()) {
        SegmentedButton(
            selected = selectedMode == GameMode.PLAYER_VS_PLAYER,
            onClick = { onModeSelected(GameMode.PLAYER_VS_PLAYER) },
            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
            icon = { Icon(Icons.Filled.Person, contentDescription = null) }
        ) {
            Text("2 Jugadores")
        }
        SegmentedButton(
            selected = selectedMode == GameMode.PLAYER_VS_BOT,
            onClick = { onModeSelected(GameMode.PLAYER_VS_BOT) },
            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
            icon = { Icon(Icons.Filled.SmartToy, contentDescription = null) }
        ) {
            Text("Vs Bot")
        }
    }
}
